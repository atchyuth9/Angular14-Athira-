import { Component } from '@angular/core';
import { AppComponent } from '../app.component';
@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css'],
})
export class ContainerComponent {}
